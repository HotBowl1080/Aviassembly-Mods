# Flap Mod 0.23.1

Flaps are available on all 13 stock Aviassembly wings with movable control surfaces. The original Big Wing and Straight Wing use dedicated flaps. The other 11 use their existing hinged surface for both flap deployment and steering. Flaps and spoilers retain the original paid upgrade and save behavior.

## Install

1. Close Aviassembly.
2. Back up the installed `AviassemblyFlaps.dll` outside the BepInEx plugins folder.
3. Replace it with the DLL from `BepInEx/plugins/AviassemblyFlaps/` in this ZIP. Keep one installed copy.
4. Start the game. In the editor, select a wing and open its settings to add **Flaps**. With mirror mode enabled, the option applies to both wings.

## Flight controls

| Extend one setting | Retract one setting |
| --- | --- |
| Right stick down or `]` | Right stick up or `[` |

The settings are 0°, 10°, 20° and 30°. Center the stick after each move. The existing flap lever also selects a setting. The Big Wing's separately purchased spoilers still use the game's throttle-down input at idle or reverse.

## Supported wings

Big Wing, Straight Wing, Wing, Delta Wing 01, Delta Wing 02, Electron Wing, Glider Wing, Small Jet Wing, Small Recreational Wing, Tail Wing, Tailwing 02, Tailwing 03 and Tailwing 04. The Biplane Wing, Small Canard and Wood Wing have fixed surfaces.

Open `aviassembly-wing-preview.html` to inspect any of the 16 stock wings. Select a flap angle and choose **Flaps** under **View** to highlight the moving surface.

## Source and validation

This update is based on [HotBowl1080's Flap Mod 0.23.0](https://github.com/HotBowl1080/Aviassembly-Mods/tree/890c72380b3fff99403103fa699eacd58d9a20b1/Flaps), the version that matches the installed DLL. In `source`, run `build.ps1` with a .NET SDK installed. The tests in `source/tests` cover upgrade transactions, existing saves, the native wing settings and poses in both mirror orientations, and synthetic keyboard and controller input in an isolated Unity player. Physical controller operation and live flight handling remain unverified.
