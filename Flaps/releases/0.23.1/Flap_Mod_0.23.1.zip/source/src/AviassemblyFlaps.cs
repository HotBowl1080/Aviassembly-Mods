using System;
using System.Collections.Generic;

using BepInEx;
using HarmonyLib;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

[BepInPlugin("com.andrewstack.aviassembly.flaps", "Flap Mod", "0.23.1")]
public class FlapsPlugin : BaseUnityPlugin
{
    internal static int stage { get; private set; }
    internal static readonly List<FlapMarker> fittedWings = new List<FlapMarker>();
    internal static FlyingUIController flightUI;
    internal static GameObject template;
    internal static FlapsPlugin instance;
    internal static PlaneContainer activePlane;
    internal static bool spoilersRequested;
    readonly FlapFlightInput flapInput = new FlapFlightInput();
    internal static bool Supports(Wing wing)
    {
        if (!wing || !wing.orientation || WingFlapIds.Of(wing.name) == 0) return false;
        var visual = wing.GetComponentInChildren<WingVisual>(true);
        return visual && visual.controlSurface;
    }
    internal static bool SupportsSpoilers(Wing wing) => wing && WingFlapIds.Of(wing.name) == WingFlapIds.BigWing;
    internal static void LogDetail(string message) { if (instance) instance.Logger.LogInfo(message); }
    void Awake() { instance = this; new Harmony("com.andrewstack.aviassembly.flaps").PatchAll(); }
    void Update()
    {
        var current = PlaneContainer.Instance;
        if (GameManager.gameMode != GameMode.Flying || !current || !current.FlightModeInitialized) current = null;
        if (current != activePlane)
        {
            activePlane = current;
            stage = 0;
            flapInput.Reset();
        }
        var controls=InputManager.Instance;
        float largestThrottle=0f;
        if(activePlane && activePlane.planeParts!=null) foreach(PlanePart part in activePlane.planeParts)
        {
            Engine engine=part as Engine;
            if(engine && engine.isActiveAndEnabled) largestThrottle=Mathf.Max(largestThrottle,engine.currentThrottle);
        }
        spoilersRequested=activePlane && activePlane.FlightModeInitialized && controls &&
            controls.throttleInput<0f && largestThrottle<=.02f &&
            !(flightUI && flightUI.UIOpen);
        int step = flapInput.ReadStep(ShowSelector && FlapFlightInput.Allowed);
        if (step != 0) SelectStage(stage + step);
    }
    internal static bool ShowSelector
    {
        get
        {
            if (!activePlane || !activePlane.FlightModeInitialized || (flightUI && flightUI.UIOpen)) return false;
            foreach (FlapMarker marker in fittedWings)
                if (marker && marker.HasFlaps && marker.CanOperate(activePlane)) return true;
            return false;
        }
    }
    internal static void SelectStage(int desired)
    {
        if (!ShowSelector || !FlapFlightInput.Allowed) return;
        stage=Mathf.Clamp(desired,0,BigWingPreset.FlapAngles.Length-1);
    }
    internal static GameObject FindTemplate()
    {
        if (template) return template;
        foreach (Engine e in Resources.FindObjectsOfTypeAll<Engine>())
            if (e && e.settingsPrefab && e.settingsPrefab.GetComponent<EngineSettings>()) return template = e.settingsPrefab;
        return null;
    }
}

public class FlapMarker : MonoBehaviour
{
    MeshFilter filter;
    Mesh original, deployed;
    Wing wing;
    PlaneContainer owner;
    BigWingGeometry geometry;
    StraightWingGeometry straight;
    internal NativeSurfaceFlaps NativeSurface { get; private set; }
    WingUpgrades upgrades;
    float angle;
    float spoilerFraction;
    internal float SpoilerFraction { get { return spoilerFraction; } }
    public bool IsReady { get { return enabled && upgrades && upgrades.Options!=WingUpgradeOptions.None && (geometry != null || straight != null || NativeSurface != null); } }
    internal bool HasFlaps { get { return upgrades && upgrades.HasFlaps; } }
    internal bool HasSpoilers { get { return upgrades && upgrades.HasSpoilers; } }
    internal bool IsStraight { get { return straight != null; } }
    internal float CurrentAngle { get { return angle; } }
    internal float FlapAreaFraction { get { return straight==null?0f:straight.FlapAreaFraction; } }
    internal bool CanOperate(PlaneContainer plane) { return IsReady && plane && plane.FlightModeInitialized && owner==plane && isActiveAndEnabled && wing && wing.isActiveAndEnabled && wing.rb; }

    void Start()
    {
        upgrades=GetComponent<WingUpgrades>();
        if(!upgrades || upgrades.Options==WingUpgradeOptions.None){enabled=false;return;}
        InitializeGeometry();SynchronizeOwnership();
    }
    internal bool InitializeGeometry()
    {
        if(geometry!=null || straight!=null || NativeSurface!=null)return true;
        try {
            wing=GetComponent<Wing>();
            upgrades=GetComponent<WingUpgrades>();
            if (!FlapsPlugin.Supports(wing)) return false;
            owner = GetComponentInParent<PlaneContainer>();
            byte wingType = WingFlapIds.Of(wing.name);
            if (wingType != WingFlapIds.BigWing && wingType != WingFlapIds.StraightWing)
            {
                NativeSurface = new NativeSurfaceFlaps(wing, wing.GetComponentInChildren<WingVisual>(true));
                return true;
            }
            filter=GetComponent<MeshFilter>();
            if (!filter || !filter.sharedMesh) return false;
            original=upgrades && upgrades.StockMesh?upgrades.StockMesh:filter.sharedMesh;
            if(!original.isReadable || original.subMeshCount!=2) return false;
            if(wingType == WingFlapIds.StraightWing) {
                var cut=new StraightWingGeometry(original.vertices,original.normals,original.uv,original.GetTriangles(0),original.GetTriangles(1));
                cut.Pose(0f,Vector3.down);
                var uv=new Vector2[cut.vertices.Count];for(int i=0;i<uv.Length;i++)uv[i]=cut.vertices[i].uv;
                deployed=new Mesh();deployed.name="Straight Wing hinged flap";deployed.MarkDynamic();
                deployed.vertices=cut.positions;deployed.normals=cut.normals;deployed.uv=uv;deployed.subMeshCount=2;
                for(int i=0;i<2;i++)deployed.SetTriangles(cut.triangles[i].ToArray(),i,false);
                Bounds box=original.bounds;box.Expand(.9f);deployed.bounds=box;
                straight=cut;filter.sharedMesh=deployed;return true;
            }
            var shape=new BigWingGeometry(original.vertices, original.normals, original.uv,
                original.GetTriangles(0),original.GetTriangles(1));
            shape.Pose(0f,Vector3.down,0f);
            var tex=new Vector2[shape.vertices.Count];
            for(int i=0;i<tex.Length;i++) tex[i]=shape.vertices[i].uv;
            deployed=new Mesh();
            deployed.name="Big Wing deployed";
            deployed.MarkDynamic();
            deployed.vertices=shape.positions;
            deployed.normals=shape.normals;
            deployed.uv=tex;
            deployed.subMeshCount=2;
            for(int i=0;i<2;i++) deployed.SetTriangles(shape.triangles[i].ToArray(),i,false);
            Bounds bounds=original.bounds;
            bounds.Expand(.9f);
            deployed.bounds=bounds;
            geometry=shape;
            filter.sharedMesh=deployed;
            return true;
        } catch(Exception ex) { FlapsPlugin.LogDetail("Flap geometry setup failed: "+ex); }
        return false;
    }
    internal void SynchronizeOwnership()
    {
        upgrades=GetComponent<WingUpgrades>();
        if(!HasFlaps)angle=0f;
        if(!HasSpoilers)spoilerFraction=0f;
        bool installed=upgrades && upgrades.Options!=WingUpgradeOptions.None;
        enabled=installed;
        if(!installed){
            FlapsPlugin.fittedWings.Remove(this);
            NativeSurface?.Restore();
            if(filter && original)filter.sharedMesh=original;
            return;
        }
        if(!FlapsPlugin.fittedWings.Contains(this))FlapsPlugin.fittedWings.Add(this);
        if(!IsReady)return;
        if (NativeSurface != null) { NativeSurface.Apply(angle, owner); return; }
        Vector3 down=owner && owner.FlightModeInitialized && wing.rb?transform.InverseTransformVector(-wing.rb.transform.up).normalized:Vector3.down;
        if(IsStraight){straight.Pose(angle,down);deployed.vertices=straight.positions;deployed.normals=straight.normals;}
        else{geometry.Pose(angle,down,spoilerFraction);deployed.vertices=geometry.positions;deployed.normals=geometry.normals;}
        filter.sharedMesh=deployed;
    }
    void LateUpdate() => Advance(Time.deltaTime);

    internal void Advance(float deltaTime)
    {
        if(!IsReady || !wing) return;
        var parent = GetComponentInParent<PlaneContainer>();
        bool ownerChanged = parent != owner;
        if (ownerChanged) owner = parent;
        bool flying = CanOperate(FlapsPlugin.activePlane);
        float next=flying && HasFlaps ? Mathf.MoveTowards(ownerChanged?0f:angle,BigWingPreset.Angle(FlapsPlugin.stage),45f*deltaTime) : 0f;
        float nextSpoiler=flying && HasSpoilers ? Mathf.MoveTowards(spoilerFraction,FlapsPlugin.spoilersRequested?1f:0f,3f*deltaTime) : 0f;
        if (NativeSurface != null)
        {
            angle = next;
            NativeSurface.Apply(angle, owner);
            return;
        }
        if(!ownerChanged && next==angle && nextSpoiler==spoilerFraction) return;
        angle=next;
        spoilerFraction=nextSpoiler;
        Vector3 localDown=flying?transform.InverseTransformVector(-wing.rb.transform.up).normalized:Vector3.down;
        if(IsStraight){straight.Pose(angle,localDown);deployed.vertices=straight.positions;deployed.normals=straight.normals;}
        else{geometry.Pose(angle,localDown,spoilerFraction);deployed.vertices=geometry.positions;deployed.normals=geometry.normals;}
        if(filter.sharedMesh!=deployed) filter.sharedMesh=deployed;
    }
    void OnDisable() => NativeSurface?.Restore();

    void OnDestroy()
    {
        FlapsPlugin.fittedWings.Remove(this);
        NativeSurface?.Restore();
        if(filter && deployed && filter.sharedMesh==deployed) filter.sharedMesh=original;
        if(deployed) Destroy(deployed);
    }
}

[HarmonyPatch(typeof(PlacementUI), "LateUpdate")]
public static class EnableWingSettings
{
    static void Prefix(PlacementUI __instance)
    {
        if (!__instance.placer || !__instance.placer.currentSelectedPart) return;
        Wing wing = __instance.placer.currentSelectedPart.GetComponentInChildren<Wing>();
        if (FlapsPlugin.Supports(wing) && !wing.settingsPrefab)
            wing.settingsPrefab = FlapsPlugin.FindTemplate();
    }
}

public sealed class FlapOptionCircle : MaskableGraphic
{
    public bool outline;

    protected override void OnPopulateMesh(VertexHelper mesh)
    {
        Draw(mesh,rectTransform.rect,color,outline);
    }

    internal static void Draw(VertexHelper mesh,Rect rect,Color32 ink,bool outline)
    {
        mesh.Clear();
        const int segments=32;
        Vector2 center=rect.center;
        float r=Mathf.Min(rect.width,rect.height)*.5f;
        Color32 clear=ink;
        clear.a=0;
        // Feather both visible contours. The center of the selected dot is opaque.
        for(int i=0;i<segments;i++)
        {
            double a=i*2.0*Math.PI/segments;
            Vector2 dir=new Vector2((float)Math.Cos(a),(float)Math.Sin(a));
            mesh.AddVert(center+dir*(outline ? r*.70f : 0f),outline ? clear : ink,Vector2.zero);
            mesh.AddVert(center+dir*(outline ? r*.80f : r*.5f),ink,Vector2.zero);
            mesh.AddVert(center+dir*(r-.65f),ink,Vector2.zero);
            mesh.AddVert(center+dir*r,clear,Vector2.zero);
            int start=i*4, next=((i+1)%segments)*4;
            for(int band=0;band<3;band++) {
                mesh.AddTriangle(start+band,next+band+1,start+band+1);
                mesh.AddTriangle(start+band,next+band,next+band+1);
            }
        }
    }
}

[HarmonyPatch(typeof(Wing), "UpdatePart")]
public static class FlapPhysics
{
    static void Prefix(Wing __instance,out float __state)
    {
        __state=__instance.liftForce;
        var marker=__instance.GetComponent<FlapMarker>();
        if(marker && marker.IsReady) __instance.liftForce*=1f-.55f*marker.SpoilerFraction;
    }
    static void Postfix(Wing __instance, PlaneContainer __0,float __state)
    {
        __instance.liftForce=__state;
        FlapMarker marker = __instance.GetComponent<FlapMarker>();
        if (!marker || !marker.CanOperate(__0) || !__instance.orientation) return;
        if (marker.NativeSurface != null)
        {
            marker.NativeSurface.ApplyForces(__0, marker.CurrentAngle);
            return;
        }
        if(marker.IsStraight){
            if(!__0 || !__0.FlightModeInitialized || !marker.CanOperate(__0))return;
            float weight=__instance.GetWingArea()*Mathf.Max(0f,__instance.liftForce),total=0f;
            foreach(PlanePart part in __0.planeParts){
                Wing other=part as Wing;
                if(other && other.isActiveAndEnabled && other.gameObject.activeInHierarchy && other.rb==__instance.rb)
                    total+=other.GetWingArea()*Mathf.Max(0f,other.liftForce);
            }
            var force=StraightWingAerodynamics.Evaluate(
                __instance.rb.GetPointVelocity(__instance.orientation.position),
                __instance.orientation.forward,__instance.orientation.right,
                Mathf.Sign(__instance.transform.localScale.y),marker.CurrentAngle,marker.FlapAreaFraction,
                __instance.GetWingArea(),__instance.liftForce,__instance.dragForce,
                __0.GravityMultiplier,__0.liftMultiplier,__instance.rb.mass,__0.RealGravity,
                total>0f?weight/total:0f);
            // Match the game's balanced lift origin. Drag acts through the
            // rigidbody COM instead of creating a new wing-pivot pitch moment.
            __instance.rb.AddForceAtPosition(force.lift,__0.GetLiftOrigin());
            __instance.rb.AddForce(force.drag);
            return;
        }
        float spoiler=marker.SpoilerFraction;
        __0.airbreakDrag+=.65f*spoiler;
        if(spoiler>0f && __0.IsGrounded())
        {
            Vector3 groundVelocity=Vector3.ProjectOnPlane(__instance.rb.linearVelocity,Vector3.up);
            int fittedSpoilers = 0;
            foreach (var wing in FlapsPlugin.fittedWings)
                if (wing && wing.HasSpoilers && wing.CanOperate(__0)) fittedSpoilers++;
            float deceleration=Mathf.Min(2f,groundVelocity.magnitude/(Time.fixedDeltaTime*Mathf.Max(1,fittedSpoilers)));
            __instance.rb.AddForce(-groundVelocity.normalized*deceleration*spoiler,ForceMode.Acceleration);
        }
        if(!marker.HasFlaps || FlapsPlugin.stage==0) return;
        Vector3 velocity = __instance.rb.GetPointVelocity(__instance.orientation.position);
        float speed = velocity.magnitude;
        if (speed < 0.1f) return;
        float fraction = BigWingPreset.Angle(FlapsPlugin.stage) / 30f;
        float strength = speed * speed * __instance.GetWingArea() * __instance.liftForce * __0.GravityMultiplier * __0.liftMultiplier;
        float slatLift=marker.IsStraight?0f:.08f*BigWingPreset.SlatExtension(BigWingPreset.Angle(FlapsPlugin.stage));
        Vector3 lift = Vector3.ProjectOnPlane(__instance.rb.transform.up, velocity.normalized).normalized * strength * (.25f*fraction+slatLift)*(1f-.55f*spoiler);
        Vector3 drag = -velocity.normalized * strength * 0.18f * fraction;
        __instance.rb.AddForceAtPosition(lift + drag, __instance.orientation.position);
    }
}
