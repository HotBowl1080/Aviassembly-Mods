# Aviassembly Performance 240

This BepInEx 5 plugin targets 240 FPS. Each frame has a 4.17 ms budget. Large aircraft, busy scenery and other mods all compete for that time.

## Install

1. Close Aviassembly. In Steam, open the game's **Manage** menu and choose **Browse local files**.
2. Extract the archive and copy its **BepInEx** folder into the game folder beside **Aviassembly.exe**, allowing Windows to merge folders.
3. Start the game. The plugin loads automatically. Its settings are in `BepInEx/config/aviassembly.performance240.cfg`.

To uninstall, close the game and remove `BepInEx/plugins/Aviassembly.Performance240`.

## What the mod changes

* Version 1.0.1 corrects heavy fog with Atmosphere 0.7.0. Transparent scenery and each layer of mist sort by distance from the flight camera, including while banking. The compatibility fix activates only with that version of Atmosphere.
* It sets Unity's frame target to 240 and turns VSync off at runtime. This can introduce tearing. You can change the target in the config.
* When the editor has nothing to outline or highlight, the renderer skips four temporary render targets and the outline blur. Selecting a part uses the game's usual renderer.
* The build screen refreshes aircraft weight, fuel capacity and cargo space up to 15 times per second. Each refresh reads the current parts, so changes usually appear in about 67 ms plus frame scheduling. Flight gauges and flight physics keep their original update timing.
* Every new scene starts at full detail. If at least a quarter of frames run more than 8% over budget for three consecutive one-second windows, the plugin lowers cloud sampling and caps shadow distance at 100 game units. A second sustained slowdown reduces cloud sampling to about half and caps shadows at 50 units. Existing shorter shadow distances take precedence. The chosen level lasts until the active scene changes. Set **AdaptiveDetail** to **false** to keep the game's visual settings.

## Measure a flight

Fly your usual aircraft and press **F6**. After 30 seconds, look for **Benchmark |** in `BepInEx/LogOutput.log`. The report includes average FPS, the 99th percentile frame time, the longest frame and the percentage of frames within budget. A constant 240 FPS requires **100% within 4.167 ms** throughout the measured run. The benchmark measures intervals between game updates. Display refresh and presentation timing are separate.

Press F6 again to restart a measurement. Changing the active scene or switching away from the game cancels it. The log resets when you restart the game.
